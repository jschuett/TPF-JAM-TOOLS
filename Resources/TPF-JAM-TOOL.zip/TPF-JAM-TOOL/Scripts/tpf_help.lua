os.execute('open "https://github.com/jschuett/tpf-jam-tool/wiki"')


